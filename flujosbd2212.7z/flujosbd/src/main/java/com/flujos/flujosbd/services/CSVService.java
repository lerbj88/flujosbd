package com.flujos.flujosbd.services;

import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;

import java.io.IOException;

public interface CSVService {
   // void crearcsvfile () throws IOException, CsvDataTypeMismatchException, CsvRequiredFieldEmptyException;
}
