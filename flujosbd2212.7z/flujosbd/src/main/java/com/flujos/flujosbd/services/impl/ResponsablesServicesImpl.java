package com.flujos.flujosbd.services.impl;

import com.flujos.flujosbd.dao.ResponsablesflujosDao;
import com.flujos.flujosbd.model.Responsablesflujos;
import com.flujos.flujosbd.services.ResponsablesServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.awt.print.Pageable;
import java.util.List;


@Repository
@Transactional
public class ResponsablesServicesImpl implements ResponsablesServices {

    @Autowired
    private ResponsablesflujosDao responsablesflujosDao;

 /*   public Page<Responsablesflujos> obtenerResponsables(Pageable pageable){

      //  Page lista = responsablesflujosDao.findAll2(pageable);

        List<Responsablesflujos> lista = responsablesflujosDao.findAll2();

        Page<Responsablesflujos> page;
        //page = new PageImpl<Responsablesflujos>(lista.subList(), pageable);


        return lista;



    }

   */
    //public void obtenresponsables ()
 public Page<Responsablesflujos> obtenerResponsables(Integer pages1)
    {
        List<Responsablesflujos> lista = responsablesflujosDao.findAll2();


        PageRequest page_req = new PageRequest(pages1, 30, Sort.Direction.ASC, "finumempleado");
        int start = page_req.getOffset();
        int end = (start + page_req.getPageSize()) > lista.size() ? lista.size() : (start + page_req.getPageSize());

        Page<Responsablesflujos> pages;
        pages = new PageImpl<Responsablesflujos>(lista.subList(start, end), page_req, lista.size());

        return pages;
    }
}
