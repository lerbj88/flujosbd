package com.flujos.flujosbd.services;

import com.flujos.flujosbd.model.Responsablesflujos;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.awt.print.Pageable;
import java.util.List;

@Repository
public interface ResponsablesServices
    //   extends PagingAndSortingRepository<Responsablesflujos, String>
{



    Page<Responsablesflujos> obtenerResponsables(Integer pages1);

//   public void obtenresponsables();


}
