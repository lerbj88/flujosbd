package com.flujos.flujosbd.controller;

import com.flujos.flujosbd.dao.FlujosDao;
import com.flujos.flujosbd.dao.ResponsablesflujosDao;
import com.flujos.flujosbd.model.Flujos;
import com.flujos.flujosbd.model.Responsablesflujos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.SQLException;
import java.util.List;

@Controller
public class FlujosController {


    @Autowired
    private FlujosDao flujosDao;


    @RequestMapping(value = { "flujos/list" }, method = RequestMethod.GET)
    public String listarUsuarios(@RequestParam(name = "id_flujo", required = false) Short id_flujo, Model model) throws SQLException {
        if (id_flujo != null) {
            model.addAttribute("key", id_flujo);
            Flujos flujos = (Flujos) flujosDao.findById_flujo(id_flujo);
            model.addAttribute("lista", flujos);
            return "flujos/list";
        } else {
            List<Flujos> list = flujosDao.findAll();
            model.addAttribute("lista", list);
            return "flujos/list";
        }
    }



    @RequestMapping(value = {"flujos/form"}, method = RequestMethod.GET)
    public String form(@RequestParam(name = "id_flujo", required = false) Short id_flujo, ModelMap model)throws SQLException {
        if (id_flujo != null) {
            Flujos flujos = (Flujos) flujosDao.obtenerFlujo(id_flujo);
            model.addAttribute("flujo", flujos);
        }
        else {
            Flujos flujos = new Flujos();
            model.addAttribute("flujo", flujos);
            model.addAttribute("outMessage", "");
        }
        return "flujos/form";
    }


    @PostMapping(value = "flujos/form")
    public String crearResponsableflujo(
            @RequestParam("id_flujo") Short id_flujo,
            @RequestParam("descripcion") String descripcion,
            Model model) {
        flujosDao.crearFlujo(id_flujo, descripcion);
        //  System.out.println("name = " + fiusuario + ", password = " + fcpassword + ", rol = "+ idrol);
        return "redirect:/flujos/list";
    }

    @RequestMapping("flujos/eliminarflujo")
    public String eliminarUsuario (@RequestParam("id_flujo") Short id_flujo){
        flujosDao.eliminarFlujo(id_flujo);
        return "redirect:list";
    }

}
