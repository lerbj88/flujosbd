package com.flujos.flujosbd.dao;


import com.flujos.flujosbd.model.Sucursal;

public interface SucursalesDao {
    public String obtenerSucursal(Integer fisucursal);
}
