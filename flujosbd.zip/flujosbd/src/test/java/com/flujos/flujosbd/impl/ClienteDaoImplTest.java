package com.flujos.flujosbd.impl;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.sql.SQLException;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class ClienteDaoImplTest {
/*
    @Resource
    private TiendaDao tiendaDao;

    @Test
    public void queryTienda() throws SQLException {
        //List<Object> list =tiendaDao.listTiendas2();
       ///  clienteDao.crearCliente("777","777","777","777","777");

    //     }
//System.out.println(list);
}*/
}