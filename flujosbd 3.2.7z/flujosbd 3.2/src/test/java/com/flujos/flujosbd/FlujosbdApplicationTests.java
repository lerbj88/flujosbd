package com.flujos.flujosbd;

import com.flujos.flujosbd.dao.*;
import com.flujos.flujosbd.model.Flujos;
import com.flujos.flujosbd.model.Taex_errormensajestienda;
import com.flujos.flujosbd.model.Usuario;
import com.flujos.flujosbd.model.UsuariosFlujos;
import com.flujos.flujosbd.services.ReenviosService;
import com.flujos.flujosbd.services.UsuarioService;
import com.flujos.flujosbd.services.UsuariosFlujosService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FlujosbdApplicationTests {



    @Autowired
    //UsuarioDao usuarioDao;
            //FlujosDao flujosDao;
    //SucursalesDao sucursalesDao;
    //UsuarioService usuarioService;
    //        UsuariosFlujosDao usuariosFlujosDao;
            ReenviosService reenviosService;

  //Taex_histmensajestiendaDao taex_histmensajestiendaDao;

   // UsuariosFlujosService usuariosFlujosService;

  //  Taex_errormensajestiendaDao taex_errormensajestiendaDao;
  // Taex_mensajestiendaDao taex_mensajestiendaDao;


    @Test
    public void test () throws IOException {
     //   clientDao.insertarCliente("jose1","jose1");

        //System.out.println("insert exitoso");

       // clienteDao.insertarCliente2("jose21","jose21");

        //tiendaDao.listTiendas2();

        //opencsv.Readercsv();
    //    opencsv.listClientes();
        //usuarioDao.findAll();

    //    usuarioDao.findByUsuario(345310);
        //usuarioDao.crearUsuario(171024, "123", 1);
     //   usuarioDao.editarPerfilUsuario(345310,"1234", "123","123");
        //usuarioDao.validarPassword();
//flujosDao.eliminarFlujo((short) 500);


           //usuarioService.actualizarContrasena(345310,"1234", "123","123");
         //   sucursalesDao.obtenerSucursal(100);

        //usuariosFlujosDao.listarFlujos(345310);
      //  usuariosFlujosDao.obtenerFlujos(345310);

        //reenviosService.Obtenercadenasporsucursalflujo(107,1928);

     //   reenviosService.EnviarPendientes(107,"97931557501");
        reenviosService.EnviarHistorico(6, new String[]{"000000121562268", "000000121561621", "903071801336653"});

   //     flujosDao.obtenerFlujosxUsuario(345310);

  //                  taex_mensajestiendaDao.obtenerFlujos("107,103,146");

          //  taex_errormensajestiendaDao.obtenerSucursal(107,"874321313156");
            //taex_histmensajestiendaDao.consultarCadenas(107,1928,"2019-04-02","2019-04-02");

      //  usuariosFlujosService.agregarFlujo(345310, 107);

     //   taex_mensajestiendaDao.InsertarPendientes(1,1,1,1,"00",0, 0,0, "2019-03-28 10:39:51.000000", "2019-03-28 10:39:51.000000",1,"cadena",1);
    }

}

