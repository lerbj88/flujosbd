package com.flujos.flujosbd.dao.impl;


import com.flujos.flujosbd.dao.Taex_histmensajestiendaDao;
import com.flujos.flujosbd.model.Taex_histmensajestienda;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository
@Transactional
public class Taex_histmensajestiendaDaoImpl extends JdbcDaoSupport implements Taex_histmensajestiendaDao {


    @Autowired
    private DataSource dataSource2;
    private JdbcTemplate jdbcTemplate;

    public Taex_histmensajestiendaDaoImpl(DataSource dataSource2) {
        this.setDataSource(dataSource2);
        this.jdbcTemplate = new JdbcTemplate(dataSource2);
    }

    static final String PROC_NAME = "SPINSHISTORY";
    private static final String CAT_NAME = "SYSTEM";



    public String InsertarHistorico(Number fnflujoid, Number fnpaisdest, Number fncanaldest, Number fnsucursaldest, String fnfolioconsec, String fdfechaproceso, Number fnpaisorig, Number fncanalorig, Number fnsucursalorig, String fdfechainsercion, String fdfechaenviotda, Number fnstatus, Number fnnotransaccion, String fccadenaejec, Number fnnointentos ) {

        String mensjae = "Cadena insertada en historico exitosamente";
        SimpleJdbcCall jdbcCall = new
                SimpleJdbcCall(getDataSource())
                .withSchemaName(CAT_NAME)
                .withProcedureName(PROC_NAME);

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("pnflujoid", fnflujoid)
                .addValue("pnpaisdest", fnpaisdest)
                .addValue("pncanaldest", fncanaldest)
                .addValue("pnsucursaldest", fnsucursaldest)
                .addValue("pcfolioconsec", fnfolioconsec)
                .addValue("pdfechaproceso", fdfechaproceso)
                .addValue("pnpaisorig", fnpaisorig)
                .addValue("pncanalorig", fncanalorig)
                .addValue("pnsucursalorig", fnsucursalorig)
                .addValue("pdfechainsercion", fdfechainsercion)
                .addValue("pdfechaenviotda", fdfechaenviotda)
                .addValue("pnstatus", fnstatus)
                .addValue("pnnotransaccion", fnnotransaccion)
                .addValue("pccadenaejec", fccadenaejec)
                .addValue("pnnointentos", fnnointentos)
                ;
        jdbcCall.execute(in);
      //  Map<String, Object> out = jdbcCall.execute(in);
        //String outMessage2 = (String) out.get("P_RESULT");
        return mensjae;

    }


    public List<Taex_histmensajestienda> consultarCadenas(String cadena){



        String sql = cadena;

        List<Taex_histmensajestienda> lista = new ArrayList<Taex_histmensajestienda>();

        List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);
        for (Map row : rows) {
            Taex_histmensajestienda taex_histmensajestienda = new Taex_histmensajestienda();
            taex_histmensajestienda.setFnflujoid((Number)(row.get("fnflujoid")));
            taex_histmensajestienda.setFnpaisdest((Number)(row.get("fnpaisdest")));
            taex_histmensajestienda.setFncanaldest((Number)(row.get("fncanaldest")));
            taex_histmensajestienda.setFnsucursaldest((Number)(row.get("fnsucursaldest")));
            taex_histmensajestienda.setFnfolioconsec((String)(row.get("fnfolioconsec")));
            //taex_histmensajestienda.setFnnointentos((Number) (row.get("fnnointentos")));
            taex_histmensajestienda.setFdfechaproceso((Date) (row.get("fdfechaproceso")));
            taex_histmensajestienda.setFccadenaejec((String) (row.get("fccadenaejec")));
            taex_histmensajestienda.setFnnointentos((Number) (row.get("fnnointentos")));
            lista.add(taex_histmensajestienda);
        }

        logger.info(lista);
        return lista;

    }
}
