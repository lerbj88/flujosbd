package com.flujos.flujosbd.services.Impl;

import com.flujos.flujosbd.dao.UsuarioDao;
import com.flujos.flujosbd.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;
import java.util.logging.Logger;

@Repository
@Transactional
public class UsuarioServiceImpl implements UsuarioService {


    @Autowired
    private UsuarioDao usuarioDao;


    private static final Logger logger = Logger.getLogger( UsuarioServiceImpl.class.getName() );


    public String actualizarContrasena (Integer fiusuario, String fcpassword, String fcpassword1, String fcpassword2)
    {

        String mensaje ="";
        String mensaje2 = "";

        String pwddb = usuarioDao.obtenerContrasena(fiusuario);

        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

        if (passwordEncoder.matches(fcpassword, pwddb)) {

            if (Objects.equals(fcpassword1, fcpassword2)){

                String password = fcpassword1;
                BCryptPasswordEncoder passwordEncoder2 = new BCryptPasswordEncoder();
                String pwd = passwordEncoder2.encode(password);

                 mensaje2 = usuarioDao.actualizarContrasena(fiusuario,pwd);

                logger.info(mensaje);
                return mensaje2;

            }
            else
            {
                String pwdnuevo = "Error - El valor de las contrasenas nuevas no coinciden";
                mensaje = pwdnuevo;
                logger.info(mensaje);
                return mensaje;
            }


        } else {
            String pwdactual = "Error - La contrasena actual no es valida";
            mensaje = pwdactual;
            logger.info(mensaje);
            return mensaje;

        }



    }
}
