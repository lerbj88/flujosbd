package com.flujos.flujosbd.services;

public interface UsuarioService {

   public String actualizarContrasena(Integer fiusuario, String fcpassword, String fcpassword1, String fcpassword2);


}
