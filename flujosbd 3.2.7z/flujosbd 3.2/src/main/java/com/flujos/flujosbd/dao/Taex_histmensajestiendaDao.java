package com.flujos.flujosbd.dao;


import com.flujos.flujosbd.model.Taex_errormensajestienda;
import com.flujos.flujosbd.model.Taex_histmensajestienda;

import java.util.List;

public interface Taex_histmensajestiendaDao {
    public String InsertarHistorico(Number fnflujoid, Number fnpaisdest, Number fncanaldest, Number fnsucursaldest, String fnfolioconsec, String fdfechaproceso, Number fnpaisorig, Number fncanalorig, Number fnsucursalorig, String fdfechainsercion, String fdfechaenviotda, Number fnstatus, Number fnnotransaccion, String fccadenaejec, Number fnnointentos );
    List<Taex_histmensajestienda> consultarCadenas(String cadena);
}
