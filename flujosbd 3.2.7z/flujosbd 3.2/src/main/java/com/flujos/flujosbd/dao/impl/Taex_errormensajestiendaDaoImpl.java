package com.flujos.flujosbd.dao.impl;

import com.flujos.flujosbd.dao.Taex_errormensajestiendaDao;
import com.flujos.flujosbd.model.Taex_errormensajestienda;
import com.flujos.flujosbd.model.UsuariosFlujos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;


@Repository
@Transactional
public class Taex_errormensajestiendaDaoImpl extends JdbcDaoSupport implements Taex_errormensajestiendaDao {


    @Autowired
    private DataSource dataSource2;
    private JdbcTemplate jdbcTemplate;

    public Taex_errormensajestiendaDaoImpl(DataSource dataSource2) {
        this.setDataSource(dataSource2);
        this.jdbcTemplate = new JdbcTemplate(dataSource2);
    }



    static final String PROC_NAME = "SPDELERROR";
    private static final String CAT_NAME = "SYSTEM";

    public List<Taex_errormensajestienda> obtenerFlujos(String flujos)  {

        String flujoid = "fnflujoid";
        String counter = "total";

       // System.out.print(flujos);



        String sql = "SELECT "+ flujoid +", count(*)  " + counter +" FROM TAEX_ERRORMENSAJESTIENDA " +
                       "WHERE fnstatus=0 and fnflujoid in ("+flujos+") group by fnflujoid";

        List<Taex_errormensajestienda> lista = new ArrayList<Taex_errormensajestienda>();

        List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);
        for (Map row : rows) {
            Taex_errormensajestienda taex_errormensajestienda = new Taex_errormensajestienda();
            taex_errormensajestienda.setFnflujoid((Number)(row.get("fnflujoid")));
            taex_errormensajestienda.setTotal((Number)row.get("total"));
            lista.add(taex_errormensajestienda);
        }

        System.out.print("lista agrupada"+lista);

        logger.info(lista);
        return lista;
    }


    public List<Taex_errormensajestienda> obtenerSucursales(Integer fnflujoid)  {


        String counter = "total";

        String sql = "SELECT  FNSUCURSALDEST"+", count(*)  " + counter +" FROM TAEX_ERRORMENSAJESTIENDA " +
                "WHERE fnstatus=0 and fnflujoid in ("+fnflujoid+") group by FNSUCURSALDEST";

        List<Taex_errormensajestienda> lista = new ArrayList<Taex_errormensajestienda>();

        List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);
        for (Map row : rows) {
            Taex_errormensajestienda taex_errormensajestienda = new Taex_errormensajestienda();
            taex_errormensajestienda.setFnsucursaldest((Number)(row.get("fnsucursaldest")));
            taex_errormensajestienda.setTotal((Number)row.get("total"));
            lista.add(taex_errormensajestienda);
        }

        System.out.print("lista agrupada"+lista);

        logger.info(lista);
        return lista;
    }



    public List<Taex_errormensajestienda> obtenerCadenas(Integer fnflujoid, Integer fnsucursaldest)  {



        String sql = "SELECT FNPAISDEST, FNCANALDEST, FNSUCURSALDEST, "+
                "FNFOLIOCONSEC, FNNOINTENTOS, FDFECHAPROCESO, "+
                "FCCADENAEJEC, FCDESCERROR FROM TAEX_ERRORMENSAJESTIENDA "+
        "WHERE FNSTATUS=0 AND "+
                "FNFLUJOID  ="+fnflujoid +
        " AND FNPAISDEST >= 0 AND FNCANALDEST >= 0" +
                " AND FNSUCURSALDEST ="+ fnsucursaldest;

        List<Taex_errormensajestienda> lista = new ArrayList<Taex_errormensajestienda>();

        List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);
        for (Map row : rows) {
            Taex_errormensajestienda taex_errormensajestienda = new Taex_errormensajestienda();
            taex_errormensajestienda.setFnpaisdest((Number)(row.get("fnpaisdest")));
            taex_errormensajestienda.setFncanaldest((Number)(row.get("fncanaldest")));
            taex_errormensajestienda.setFnsucursaldest((Number)(row.get("fnsucursaldest")));
            taex_errormensajestienda.setFnfolioconsec((String)(row.get("fnfolioconsec")));
            taex_errormensajestienda.setFnnointentos((Number) (row.get("fnnointentos")));
            taex_errormensajestienda.setFdfechaproceso((Date) (row.get("fdfechaproceso")));
            taex_errormensajestienda.setFccadenaejec((String) (row.get("fccadenaejec")));
            taex_errormensajestienda.setFcdescerror((String) (row.get("fcdescerror")));
            lista.add(taex_errormensajestienda);
        }

        System.out.print("lista agrupada"+lista);

        logger.info(lista);
        return lista;
    }



    public List<Taex_errormensajestienda> obtenerCadena(Integer fnflujoid, String fnfolioconsec)  {

        fnfolioconsec = "'"+fnfolioconsec+"'";

        String sql = "SELECT FNFLUJOID,FNPAISDEST,FNCANALDEST,FNSUCURSALDEST,FNFOLIOCONSEC,FNPAISORIG,FNCANALORIG," +
                "FNSUCURSALORIG,FDFECHAINSERCION,FDFECHAENVIOTDA,FCCADENAEJEC,FNNOINTENTOS "+
                " FROM TAEX_ERRORMENSAJESTIENDA "+
                "WHERE FNSTATUS=0 AND "+
                "FNFLUJOID  ="+fnflujoid +
                " AND FNFOLIOCONSEC  ="+fnfolioconsec +
                " AND FNPAISDEST >= 0 AND FNCANALDEST >= 0" +
                " AND FNSUCURSALDEST >=0";

        List<Taex_errormensajestienda> lista = new ArrayList<Taex_errormensajestienda>();

        List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);
        for (Map row : rows) {
            Taex_errormensajestienda taex_errormensajestienda = new Taex_errormensajestienda();
            taex_errormensajestienda.setFnflujoid((Number)(row.get("fnflujoid")));
            taex_errormensajestienda.setFnpaisdest((Number)(row.get("fnpaisdest")));
            taex_errormensajestienda.setFncanaldest((Number)(row.get("fncanaldest")));
            taex_errormensajestienda.setFnsucursaldest((Number)(row.get("fnsucursaldest")));
            taex_errormensajestienda.setFnfolioconsec((String)(row.get("fnfolioconsec")));
            taex_errormensajestienda.setFnpaisorig((Number) (row.get("fnpaisorig")));
            taex_errormensajestienda.setFncanalorig((Number) (row.get("fncanalorig")));
            taex_errormensajestienda.setFncanalorig((Number) (row.get("fncanalorig")));
            taex_errormensajestienda.setFnsucursalorig((Number) (row.get("fnsucursalorig")));
            taex_errormensajestienda.setFdfechainsercion((Date) (row.get("fdfechainsercion")));
            taex_errormensajestienda.setFdfechaenviotda((Date) (row.get("fdfechaenviotda")));
            taex_errormensajestienda.setFccadenaejec((String) (row.get("fccadenaejec")));
            taex_errormensajestienda.setFnnointentos((Number) (row.get("fnnointentos")));
            lista.add(taex_errormensajestienda);
        }



        logger.info(lista);
        return lista;
    }


    public String eliminarCadena(Number fnflujoid, Number fnpaisdest, Number fncanaldest, Number fnsucursaldest, String fcfolioconsec) {
        String mensaje = "";

        String mensjae = "Cadena eliminada de errores exitosamente";
        SimpleJdbcCall jdbcCall = new
                SimpleJdbcCall(getDataSource())
                .withSchemaName(CAT_NAME)
                .withProcedureName(PROC_NAME);

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("pnflujoid", fnflujoid)
                .addValue("pnpaisdest", fnpaisdest)
                .addValue("pncanaldest", fncanaldest)
                .addValue("pnsucursaldest", fnsucursaldest)
                .addValue("pcfolioconsec", fcfolioconsec)
               ;
        jdbcCall.execute(in);

        return mensaje;
    }

    public String obtenerSucursal (Number fnflujoid, String fnfolioconsec)
    {

        System.out.print("desdemetodo"+fnfolioconsec);

        String sql2 = "SELECT fnsucursaldest FROM SYSTEM.TAEX_ERRORMENSAJESTIENDA WHERE FNFLUJOID = ? AND FNFOLIOCONSEC=? " +
                " AND FNPAISDEST >= 0 AND FNCANALDEST >= 0 AND\n" +
                "        FNSUCURSALDEST >=0" +
                "";

        String sucursal = (String)getJdbcTemplate().queryForObject(
                sql2, new Object[] {fnflujoid, fnfolioconsec}, String.class);

logger.info(sucursal);

    return sucursal;

    }



    public List<Taex_errormensajestienda> filtrarCadenas(String  cadena)  {



        String sql = cadena;

        List<Taex_errormensajestienda> lista = new ArrayList<Taex_errormensajestienda>();

        List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);
        for (Map row : rows) {
            Taex_errormensajestienda taex_errormensajestienda = new Taex_errormensajestienda();
            taex_errormensajestienda.setFnpaisdest((Number)(row.get("fnpaisdest")));
            taex_errormensajestienda.setFncanaldest((Number)(row.get("fncanaldest")));
            taex_errormensajestienda.setFnsucursaldest((Number)(row.get("fnsucursaldest")));
            taex_errormensajestienda.setFnfolioconsec((String)(row.get("fnfolioconsec")));
            taex_errormensajestienda.setFnnointentos((Number) (row.get("fnnointentos")));
            taex_errormensajestienda.setFdfechaproceso((Date) (row.get("fdfechaproceso")));
            taex_errormensajestienda.setFccadenaejec((String) (row.get("fccadenaejec")));
            taex_errormensajestienda.setFcdescerror((String) (row.get("fcdescerror")));
            lista.add(taex_errormensajestienda);
        }

        System.out.print("lista FILTRADA"+lista);

        logger.info(lista);
        return lista;
    }


}
