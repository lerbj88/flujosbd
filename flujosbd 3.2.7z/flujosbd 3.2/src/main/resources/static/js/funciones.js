$('#select-all').click(function(event) {   
    if(this.checked) {

        $(':checkbox').each(function() {
            this.checked = true;                        
        });
    } else {
        $(':checkbox').each(function() {
            this.checked = false;                       
        });
    }
});


function retornarFecha()
{
    var fecha
    fecha=new Date();
    var cadena=fecha.getDate()+'/'+(fecha.getMonth()+1)+'/'+fecha.getYear();
    return cadena;
}


    $(document).ready(function() {
        changePageAndSize();

        $(document).on("click", ".show-alert", function(e) {
            bootbox.alert("Hello world!", function() {
                console.log("Alert Callback");
            });
        });


        $(document).on("click", "#delUser", function(e) {
            bootbox.confirm("confirma!", function() {

            });
        });

    });

function changePageAndSize() {
    $('#pageSizeSelect').change(function(evt) {
        window.location.replace("/?size=" + this.value + "&page=1");
    });
}

